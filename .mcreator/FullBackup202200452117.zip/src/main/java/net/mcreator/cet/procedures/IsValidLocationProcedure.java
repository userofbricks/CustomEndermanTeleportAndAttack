package net.mcreator.cet.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class IsValidLocationProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return false;
		double checkAirAt = 0;
		if (world.getBlockState(new BlockPos(x, y - 1, z)).isFaceSturdy(world, new BlockPos(x, y - 1, z), Direction.UP)) {
			checkAirAt = 0;
			while (checkAirAt <= Math.ceil(entity.getBbHeight())) {
				if (!((world.getBlockState(new BlockPos(x, y + checkAirAt, z))).getBlock() == Blocks.AIR)) {
					return false;
				}
				checkAirAt = checkAirAt + 1;
			}
			return true;
		}
		return false;
	}
}
