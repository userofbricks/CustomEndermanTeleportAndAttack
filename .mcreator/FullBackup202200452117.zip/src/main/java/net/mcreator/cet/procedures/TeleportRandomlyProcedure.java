package net.mcreator.cet.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;

import java.util.List;
import java.util.ArrayList;

public class TeleportRandomlyProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		boolean foundLocation = false;
		double xCord = 0;
		double yCord = 0;
		double zCord = 0;
		double maxY = 0;
		double minY = 0;
		double maxDistance = 0;
		double blockSlot = 0;
		List<BlockPos> ValidLocations = new ArrayList<>();
		maxDistance = entity.getBbHeight();
		maxDistance = world.dayTime();
		maxDistance = x;
		maxDistance = z;
		maxDistance = 32;
		xCord = maxDistance * (-1);
		yCord = maxDistance * (-1);
		zCord = maxDistance * (-1);
		while (xCord <= maxDistance) {
			while (yCord <= maxDistance) {
				while (zCord <= maxDistance) {
					if (y + yCord <= 319 && y + yCord > -64 && Math.sqrt(xCord * xCord + yCord * yCord + zCord * zCord) <= maxDistance) {
						if (IsValidLocationProcedure.execute(world, xCord, yCord, zCord, entity)) {
							ValidLocations.add(new BlockPos(x + xCord, y + yCord, z + zCord));
						}
					}
					zCord = zCord + 1;
				}
				zCord = maxDistance * (-1);
				yCord = yCord + 1;
			}
			yCord = maxDistance * (-1);
			xCord = xCord + 1;
		}
		if (ValidLocations.size() > 0) {
			blockSlot = Mth.nextInt(RandomSource.create(), 0, (int) (ValidLocations.size() - 1));
			BlockPos finalLocation = ValidLocations.get((int) blockSlot);
			{
				Entity _ent = entity;
				_ent.teleportTo(finalLocation.getX(), finalLocation.getY(), finalLocation.getZ());
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(finalLocation.getX(), finalLocation.getY(), finalLocation.getZ(), _ent.getYRot(),
							_ent.getXRot());
			}
		}
	}
}
